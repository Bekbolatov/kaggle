path_train = './raw/train.csv' 
path_test  = './raw/test.csv' 
path_sampleSubmission = './raw/sampleSubmission.csv'

path_w2v_pretrained_model = '../tools-w2v/GoogleNews-vectors-negative300.bin'

path_processed = './processed/'
path_features = './processed/'
path_tmp = './tmp/'

path_submit = './submit/'
